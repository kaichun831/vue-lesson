//管理路由 npm install vue-router
import { createRouter, createWebHistory } from 'vue-router'
import MainScreen from './screens/MainScreen.vue'
import About from './screens/About.vue'
import NotFound from './screens/NotFoundScreen.vue'
const routes = [
  {
    path: '/',
    name: 'Home',
    component: () => MainScreen,
  },
  {
    path: '/about',
    name: 'About',
    component: () => About,
  },
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    component: () => NotFound,
  },
]
const router = createRouter({
  history: createWebHistory(),
  routes,
})

export default router
