<template>
  <h1>404 - Not Found</h1>
  <p>It looks like this page doesn't exist.</p>
  <a href="/">Go back to the homepage</a>
</template>
