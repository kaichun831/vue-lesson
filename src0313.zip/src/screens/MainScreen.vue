<template>
  <h1>Main</h1>
  <button @click="routeToAbout">To About</button>
</template>

<script setup>
import Page from '@/components/Page.vue'
import Card from '@/components/Card.vue'
import { useRouter } from 'vue-router'
const router = useRouter()
function routeToAbout() {
  // router.push('/about');
  router.push({ name: 'About' })
}
</script>

<style scoped lang="scss">
.active {
  color: red;
}
.pStyle {
  font-size: 40px;
}

.currentClass {
  color: blue;
}

.errorClass {
  color: green;
}
</style>
