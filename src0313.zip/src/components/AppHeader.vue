<template>
  <header class="header" v-if="show">
    <img alt="Vue logo" class="logo" src=".././assets/images/pretty.png" width="50" height="50" />
    <div class="wrapper"></div>
  </header>
</template>

<script setup>
import { defineProps } from 'vue'

defineProps({
  show: {
    type: Boolean,
    default: true,
  },
})
</script>

<style scoped lang="scss">
header {
  line-height: 1.5;
  background-color: antiquewhite;
}
</style>
