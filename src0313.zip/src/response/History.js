class History {
  constructor(title, since, companyName, content, image) {
    this.title = title
    this.since = since
    this.companyName = companyName
    this.content = content
    this.image = image
  }
}

export default History
